
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'valentinadei',
  applicationName: 'shortlinker',
  appUid: 'YcqfkRhcKJBQCNMt8L',
  orgUid: 'ed5830cf-ee9f-42ee-a374-b524e9878601',
  deploymentUid: 'fffb2736-41c6-4713-9b86-0e583987ea10',
  serviceName: 'shortlinker',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.1.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'shortlinker-dev-authorize', timeout: 6 };

try {
  const userHandler = require('./build/functions/authorize.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}