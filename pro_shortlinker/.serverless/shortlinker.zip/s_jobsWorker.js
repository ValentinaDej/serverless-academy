
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'valentinadei',
  applicationName: 'shortlinker',
  appUid: 'YcqfkRhcKJBQCNMt8L',
  orgUid: 'ed5830cf-ee9f-42ee-a374-b524e9878601',
  deploymentUid: '299de99f-365f-4457-a1db-934ce0674ec3',
  serviceName: 'shortlinker',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '7.1.0',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'shortlinker-dev-jobsWorker', timeout: 6 };

try {
  const userHandler = require('./build/functions/api/email/worker.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}